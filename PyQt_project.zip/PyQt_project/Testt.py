import sys

from PyQt5.QtWidgets import QApplication, QMainWindow


from PyQt5 import QtCore, QtGui, QtWidgets


class Testy(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(1109, 912)
        self.Picture = QtWidgets.QLabel(Form)
        self.Picture.setGeometry(QtCore.QRect(320, 160, 471, 511))
        self.Picture.setObjectName("Picture")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.Picture.setText(_translate("Form", "TextLabel"))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Testy()
    ex.show()
    sys.exit(app.exec_())